# Preparation Plan — Asper Business Case Competition 2027

**Team:** 4 students (Finance, Innovation, Computer Science, General Business Administration) + faculty advisor Prof. Dr. Christoph Weisser (HSBI)
**Competition:** February 18–22, 2027, Asper School of Business, University of Manitoba, Winnipeg
**Planning horizon:** August 2026 → February 2027 (~28 weeks)
**Dated schedule:** see `week_by_week_plan.md` for the calendar version of this plan (its calendar phases compress this file's concept phases into slightly different week boundaries — the calendar governs)

---

## Design principles

1. **Train for the weights.** The two short-prep rounds (boardroom 30 % + traditional 45 %) decide 75 % of the score. Most training time therefore goes into timed short-prep simulations, not into polishing the prepared case. Within every case, train for the official judging rubric: **Implementation & Resources is the heaviest criterion (2.5×)**, ahead of Analysis (2.0×) and Recommendation (2.0×) — see `01-competition/facts_and_rules.md`.
2. **Leads, not silos.** Each student owns a functional lens but must be able to carry the whole storyline. Judges expect every member to answer any question.
3. **Competition-identical conditions.** Every mock case is run under the real rules: 3–4 h prep, one laptop per student, no phones/smartwatches, no coach contact after release, all four members speak, yellow/red time cards.
4. **Feedback beats volume.** Every simulation ends with a structured debrief (video recording, judge-style scoring rubric, one improvement goal per person for the next round).

---

## Team roles

| Student | Lead role | Owns | Stretch goal |
|---|---|---|---|
| Finance | Team CFO | Financial model, valuation, break-even, sensitivity, funding ask | Explaining numbers simply to non-finance judges |
| Innovation | Creative lead | Idea generation, differentiation, customer value proposition, "radical idea" framing (cf. Jazz Winnipeg 2026) | Disciplining creativity into 2–3 feasible options |
| Computer Science | Analytics & tech lead | Data analysis of case exhibits, digital/AI feasibility, implementation architecture, quick Excel/Python modelling | Business framing: translating tech into revenue/cost impact |
| General Business | Strategist & integrator | Problem framing, framework choice, storyline, slide structure, time-keeping in prep | Owning the opening and the "so what" summary |

Rotate the **opening speaker** and the **Q&A quarterback** across mock cases so all four are credible in every position.

---

## Phase 0 — Setup (Week 1)

- Kick-off meeting: walk through the slide deck (`08-briefing-slides/abcc_overview.pdf`), the rules, and this plan; agree on the weekly time commitment (target: 4–6 h/week rising to 8–10 h near the competition).
- Register the team with the organizers (aspercasecomps@umanitoba.ca) and get on the mailing list for the 2027 rules package and deadlines.
- Administrative track starts immediately: passports, eTA applications, flight options to YWG, Delta Hotel booking, travel insurance, university funding/approval.
- Set up shared infrastructure: this repo, a shared drive for case PDFs, a slide template (one clean 16:9 template the team always uses), a timer protocol.

## Phase 1 — Foundations (Weeks 2–6)

**Goal: shared language and method.**

- **Case method basics:** how to read a case in 30 minutes (skim → exhibits → problem statement → hypothesis), issue trees, MECE, hypothesis-driven analysis.
- **Framework toolkit** (see `04-training/frameworks.md`): profitability tree, 3C/4P, Porter's Five Forces, value chain, Ansoff, BCG, unit economics, market sizing, break-even, NPV/payback, SWOT-as-synthesis (not as analysis).
- **Business math drills** (30 min/week, all members): mental math, market sizing, margin/CAGR/break-even calculations without a calculator.
- **Watch and dissect** 3–4 recordings of winning case competition finals (many university competitions publish finals on YouTube). Score them with a rubric; discuss what made the winner win.
- **Role deep dives:** each lead prepares a 45-min teach-back for the team (finance: how I build a quick model; CS: how I attack case data; innovation: ideation methods; general business: storylining and the pyramid principle).
- Milestone (end W6): team cracks one mini-case (60 min, no presentation) and produces a coherent one-page recommendation.

## Phase 2 — Skill building (Weeks 7–12)

**Goal: from analysis to persuasive presentation.**

- **Slide craft:** action titles, one message per slide, horizontal logic (titles alone tell the story), clean exhibits. Build a reusable skeleton: situation → problem → options → recommendation → financials → risks → implementation roadmap → ask.
- **Presentation training:** delivery basics, handovers between speakers, the 3-minute elevator recommendation (direct training for the boardroom round), answering questions with "answer first."
- **First full mock cases** (2–3 in this phase, generous 6-h prep): full 20-min presentation + 10-min Q&A in front of the coach. Video-record everything.
- **Q&A gauntlet introduced:** after each mock presentation, 15 minutes of deliberately hard, hostile, and off-topic questions. Rule: never answer with "we didn't look at that" — bridge to what you do know.
- Milestone (end W12): a full traditional-style mock under 4-h prep with all four presenting.

## Phase 3 — Simulation under competition rules (Weeks 13–20, incl. semester break adjustments)

**Goal: speed, consistency, resilience.**

- **Weekly timed simulation**, alternating formats:
  - *Traditional:* 3-h prep → 20 min + 10 min Q&A (mirrors the 45 %-weight round — do this most often).
  - *Boardroom:* 4-h prep → one summary slide + one-page black-and-white judge brief → 3-min pitch + 22-min moderated discussion. Practise the discussion format explicitly: it is a conversation, not a presentation; seated delivery, wireless clicker, inviting judges into the logic.
- Recruit **external judges** (colleagues, alumni, local executives) for at least 4 sessions; unfamiliar faces change team behaviour.
- **Score every simulation with the official ABCC rubric** (7 categories: implementation & resources 2.5×, analysis 2.0×, recommendation 2.0×, communication, framing, impact, measurement/risks 1.0× each — see `01-competition/facts_and_rules.md`). Track scores over time in `02-plan/simulation_log.md`.
- Practise **failure modes:** a case in an unfamiliar industry, a case with heavy data exhibits (CS lead under pressure), a deliberately ambiguous case, one simulation where the projector "fails."
- Milestone (end W20): two consecutive simulations scored ≥ 80 % on the internal rubric, with every member having opened at least once.

## Phase 4 — Prepared-case sprint (release of Case 1 → submission deadline, ~2 weeks, likely late January/early February 2027)

**Goal: a submission-ready 25-minute deck, on time.**

Suggested 14-day sprint:

- **Days 1–2:** deep reading, client research (public sources only — contacting sponsor employees is prohibited), problem definition, hypothesis tree.
- **Days 3–5:** parallel workstreams by lead role (market & customer, financials, tech/data feasibility, creative options). Daily 30-min sync.
- **Days 6–7:** option selection, storyline on paper (title-only deck), coach review #1. *Coach input is allowed for this case — use it.*
- **Days 8–10:** full deck build, financial model hardened, appendix bank for Q&A.
- **Days 11–12:** two dress rehearsals (25 min + 15 min Q&A) with external audience, coach review #2.
- **Day 13:** final polish, freeze.
- **Day 14 (before the deadline, not on it):** **submit**. Late submissions are placed at the bottom of the pool — build in a 24-h buffer.

## Phase 5 — Final polish and travel (last 2 weeks)

- One light boardroom + one traditional simulation to stay sharp (no new content marathon; avoid burnout).
- Prepared-case run-throughs to internalize (not memorize word-for-word) — Q&A practice matters more than delivery at this point.
- Logistics check: documents, adapters, backup laptop chargers, USB-C/HDMI dongles, offline copies of all materials, business attire, serious winter clothing (Winnipeg in February: −20 °C is normal).
- Team charter for competition days: sleep discipline, meal plan, roles during prep windows (first 20 min = silent reading; minute 20–40 = align on problem & storyline; last 30 min = rehearsal, always).
- Jet-lag plan: arrive with enough buffer, shift sleep 2–3 days before departure if possible.

---

## During the competition — operating rules

- Fixed prep-window protocol (tested in simulations, not invented on site).
- The strategist owns the clock; hard timeboxes for analysis vs. slide production vs. rehearsal.
- Appendix bank: every analysis that doesn't make the main deck becomes an appendix slide for Q&A.
- After each round: 15-minute debrief max, then close the topic — next case mindset.
- Enjoy the social program deliberately: networking with judges and other teams is part of why we go.

## Risks and mitigations

| Risk | Mitigation |
|---|---|
| 2027 rules differ from 2026 | Re-verify everything after registration; update repo and deck |
| Prepared-case deadline missed | Day-14 buffer, submission owner = strategist, backup = coach reminder |
| One member ill during competition | Everyone can cover every part; shared appendix knowledge |
| Q&A in fast native-speaker English | Q&A gauntlet in English from Phase 2 onwards; vocabulary list per case |
| Tech failure on site | Offline copies, PDF fallback of every deck, printed judge brief |

## Weekly cadence (Phases 2–3)

- 1 × 3–4 h simulation or workshop (weekend)
- 1 × 60–90 min debrief + skill session (midweek)
- 30 min individual drills (business math / vocabulary / slide re-work)
