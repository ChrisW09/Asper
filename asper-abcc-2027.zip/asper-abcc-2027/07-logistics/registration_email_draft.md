# Draft: Registration / Interest E-mail to the ABCC Organizers

Send to **aspercasecomps@umanitoba.ca** (Judith Jayasuriya, Steven Harrison). Adjust freely — this is a draft, written to get every open question from `01-competition/facts_and_rules.md` answered in one exchange.

---

**Subject:** International team interest — ABCC 2027 (HSBI, Germany)

Dear Ms. Jayasuriya, dear Mr. Harrison,

I am a professor at Hochschule Bielefeld (HSBI) — University of Applied Sciences and Arts in Bielefeld, Germany, and I would like to enter a team in the **Asper Business Case Competition 2027** (February 18–22). We have followed the competition's development with great interest — not least Babeș-Bolyai's participation and win in 2026 — and would be delighted to bring a second international team to Winnipeg.

Our team would consist of **four Masters-level students** with backgrounds in finance, innovation management, computer science, and general business administration, accompanied by myself as faculty advisor. Before we finalize planning, could you help us with the following:

1. **Eligibility and entry:** Is a team of Masters-level students from a German business school eligible for the 2027 edition, and what does the registration process for an international school look like? Is there a participation fee, and what does it cover?
2. **Key dates:** When will the 2027 Competition Guide be published, and when do you expect the prepared case to be released and due?
3. **Logistics:** Should we book rooms through a competition block at the Delta Hotels Winnipeg, and from which date? Are airport transfers or shuttles provided for arriving teams?
4. **Team formalities:** What information do you need from us and by when (team roster, bios, photos, fictional team name, waivers)?

We would plan to arrive on February 16 or 17 to allow for the time difference. Please let me know if a short call would be easier — I am generally available afternoons CET.

Thank you very much, and congratulations on building such a distinctive competition — the three-round format is precisely why we want to take part.

Kind regards,

Prof. Dr. Christoph Weisser
Hochschule Bielefeld (HSBI), Germany
[phone] · christoph.j.weisser28@gmail.com

---

**After the reply:** transfer every answered deadline into `02-plan/week_by_week_plan.md` and `01-competition/facts_and_rules.md` (open-questions section), and start the eTA/flight track per `07-logistics/travel_logistics.md`.
