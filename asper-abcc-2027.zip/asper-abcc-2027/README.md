# ABCC 2027 — HSBI Team Preparation

Preparation repository for the HSBI team (4 Masters students + faculty advisor Prof. Dr. Christoph Weisser) at the **Asper Business Case Competition** — fifth annual edition, **February 18–22, 2027**, Asper School of Business, University of Manitoba, Winnipeg.

**→ Full guide to this repository: [`DOCUMENTATION.md`](DOCUMENTATION.md)** (two-layer model, file inventory, workflows, sync procedure, verification log, maintenance). **→ What changed when: [`CHANGELOG.md`](CHANGELOG.md).**

*Documentation verified 2026-08-04. Calendar position: **W1, Aug 3–9, 2026** — kick-off week, 29 weeks out.*

## Structure at a glance

53 files, ≈69,000 words across 34 markdown documents, in eight lifecycle folders:

| Folder | Contents |
|---|---|
| [`01-competition/`](01-competition/) | Rules & facts (**source of truth**), handbook, official judging scoresheet, past cases + six official PDFs |
| [`02-plan/`](02-plan/) | Preparation concept, dated week-by-week calendar (**governs on date conflicts**), simulation log |
| [`03-team/`](03-team/) | Team charter, role playbooks incl. GenAI operating procedure, coach & AI rules one-pager |
| [`04-training/`](04-training/) | Presentation & storyline guide, Q&A drills (60 questions), business math (40 drills), English phrasebook + 87 flashcards, frameworks, **exercise program** (`exercises/`: 25-question format quiz + four solved workbooks + week-mapped catalog, ≈200 items) |
| [`05-practice-cases/`](05-practice-cases/) | Three original full cases (traditional / boardroom / prepared), mini-cases 1–12, model answers |
| [`06-templates/`](06-templates/) | Slide skeletons (general 14-slide + six case types), case-type playbook, financial toolkit (xlsx), judge-brief template (docx) |
| [`07-logistics/`](07-logistics/) | Registration e-mail draft, travel logistics Germany→Winnipeg, competition-day runbook |
| [`08-briefing-slides/`](08-briefing-slides/) | Kick-off Beamer deck (.tex + 25-page .pdf) |

## The competition in one paragraph

Nine graduate teams of four compete over three days in three formats: a **prepared case** (released ~2 weeks ahead; 25-min presentation + 15-min Q&A; 25 %; deck due as .pptx by e-mail before arrival — late = bottom of pool), a **boardroom case** (4-h on-site prep; 3-min protected pitch from one summary slide + 22-min judge discussion; one-page b/w judge brief; 30 %), and a **traditional case** (3-h prep; 20 + 10; 45 %); the top three re-present frozen decks to a fresh panel. Judged by ~50 industry practitioners on a 7-category rubric in which **Implementation & Resources weighs most (2.5×)**. Everything runs in English, PowerPoint only, internet and GenAI are allowed during prep, coaches are cut off once timed cases release, and revealing your school to a judge means disqualification. In 2026 the first-ever international team (Babeș-Bolyai, Romania) won outright.

**Note the weekday shift:** Feb 18–22, 2027 falls **Thursday–Monday**, while the 2025 baseline that every day-sheet here is built on ran **Wednesday–Sunday**. The round-to-day mapping stays TBA until the 2027 agenda publishes.

## This week (W1, Aug 3–9, 2026)

1. Kick-off with `08-briefing-slides/abcc_overview.pdf`; everyone then reads `01-competition/handbook.md`
2. Sign `03-team/team_charter.md`; assign roles per `03-team/role_playbooks.md`; brief the team on `03-team/coach_and_ai_rules.md`
3. Send `07-logistics/registration_email_draft.md` to aspercasecomps@umanitoba.ca — register, confirm eligibility, get on the 2027 mailing list
4. Check all five passports (eTAs in W2); homework is `01-competition/past_cases.md` Part I and a first pass at `04-training/exercises/format_quiz.md`

Everything after that: `02-plan/week_by_week_plan.md`.

## New here?

**Team member, first 90 minutes:** `01-competition/handbook.md` → skim `02-plan/week_by_week_plan.md` → your section of `03-team/role_playbooks.md` → sign the charter → take the format quiz (target 25/25 by W3).

**Coach:** `03-team/coach_and_ai_rules.md` → `01-competition/judging_scoresheet.md` (print one per simulation judge) → `02-plan/week_by_week_plan.md` → `02-plan/simulation_log.md`.

## Compiling the briefing deck

```bash
cd 08-briefing-slides && pdflatex abcc_overview.tex && pdflatex abcc_overview.tex
```

(Or upload `abcc_overview.tex` to Overleaf. 21 frames + 4 section pages = 25 pages.)

## Publishing this repo

```bash
gh repo create asper-abcc-2027 --private --source=. --push
# or: git remote add origin git@github.com:<user>/asper-abcc-2027.git && git push -u origin main
```

Keep it **private** — `01-competition/past-case-pdfs/` holds confidential competition documents (© University of Manitoba, no reproduction or transmission).
