# ABCC 2027 — HSBI Team Preparation

Preparation repository for the HSBI team (4 Masters students + faculty advisor Prof. Dr. Christoph Weisser) at the **Asper Business Case Competition** — fifth annual edition, **February 18–22, 2027**, Asper School of Business, University of Manitoba, Winnipeg.

**→ Full guide to this repository: [`DOCUMENTATION.md`](DOCUMENTATION.md)** (structure, file inventory, workflows, maintenance).

## Structure at a glance

| Folder | Contents |
|---|---|
| [`01-competition/`](01-competition/) | Rules & facts (**source of truth**), handbook, official judging scoresheet, past cases + PDFs |
| [`02-plan/`](02-plan/) | Preparation concept, dated week-by-week calendar (governs), simulation log |
| [`03-team/`](03-team/) | Team charter, role playbooks incl. GenAI operating procedure, coach & AI rules one-pager |
| [`04-training/`](04-training/) | Presentation & storyline guide, Q&A drills, business math, English phrasebook + flashcards, frameworks, **exercise program** (`exercises/`: format quiz + four solved workbooks + week-mapped catalog, ~200 items) |
| [`05-practice-cases/`](05-practice-cases/) | Three original full cases (traditional/boardroom/prepared), twelve mini-cases in two sets, model answers |
| [`06-templates/`](06-templates/) | Slide skeletons (general + six case types), case-type playbook, financial toolkit (xlsx), judge-brief template (docx) |
| [`07-logistics/`](07-logistics/) | Registration e-mail draft, travel logistics Germany→Winnipeg, competition-day runbook |
| [`08-briefing-slides/`](08-briefing-slides/) | Kick-off Beamer deck (.tex + .pdf) |

## The competition in one paragraph

Nine graduate teams of four compete over three days in three formats: a **prepared case** (released ~2 weeks ahead; 25-min presentation + 15-min Q&A; 25 %; deck due as .pptx by e-mail before arrival — late = bottom of pool), a **boardroom case** (4-h on-site prep; 3-min pitch from one summary slide + 22-min judge discussion; one-page b/w judge brief; 30 %), and a **traditional case** (3-h prep; 20 + 10; 45 %); the top three re-present frozen decks to a fresh panel. Judged by ~50 industry practitioners on a 7-category rubric in which **Implementation & Resources weighs most (2.5×)**. Everything runs in English, internet and GenAI are allowed during prep, coaches are cut off once timed cases release, and revealing your school to a judge means disqualification. In 2026 the first-ever international team (Babeș-Bolyai, Romania) won outright.

## Next actions

1. Send `07-logistics/registration_email_draft.md` to aspercasecomps@umanitoba.ca — register, confirm eligibility, get on the 2027 mailing list
2. Passports + eTAs now; flights by early autumn (`07-logistics/travel_logistics.md`)
3. Kick-off meeting with `08-briefing-slides/abcc_overview.pdf`, then follow `02-plan/week_by_week_plan.md`

## Compiling the briefing deck

```bash
cd 08-briefing-slides && pdflatex abcc_overview.tex && pdflatex abcc_overview.tex
```

(Or upload `abcc_overview.tex` to Overleaf.)

## Publishing this repo

```bash
gh repo create asper-abcc-2027 --private --source=. --push
# or: git remote add origin git@github.com:<user>/asper-abcc-2027.git && git push -u origin main
```
